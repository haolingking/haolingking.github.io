package action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import entity.Teacher;
import service.TeacherDAO;
import serviceimple.TeacherDAOImpl;

//ѧ��Action��
public class TeacherAction extends SuperAction{

	private static final long serialVersionUID = 1L;
	
	//��ѯ����ѧ���Ķ���
	public String query(){
		
		TeacherDAO sdao = new TeacherDAOImpl();
		List<Teacher> list = sdao.queryAllStudents();
		//�Ž�session
		if(list!=null&&list.size()>0){
			
			session.setAttribute("Teacher_list", list);
		}
		return "query_success";
	}
	
	//ɾ��ѧ������
	public String delete(){
		
		TeacherDAO sdao = new TeacherDAOImpl();
		String sid = request.getParameter("sid");
		sdao.deleteTeacher(sid);
		return "delete_success";
	}
	
	//����ѧ��
	public String add() throws Exception{
		
		Teacher s = new Teacher();
		s.setSname(request.getParameter("sname"));
		s.setGender(request.getParameter("gender"));
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		s.setBirthday(sdf.parse(request.getParameter("birthday")));
		s.setAddress(request.getParameter("address"));
		TeacherDAO sdao = new TeacherDAOImpl();
		sdao.addTeacher(s);
		return "add_success";
	
	}
	
	
	//�޸�ѧ�����϶���
	public String modify(){
		
		//��ô��ݹ�����ѧ�����
		String sid = request.getParameter("sid");
		TeacherDAO sdao = new TeacherDAOImpl();
		Teacher s = sdao.queryTeacherBySid(sid);
		//�����ڻỰ��
		session.setAttribute("modify_Teacher", s);
		return "modify_success";
		
	}
	
	
	//�����޸ĺ��ѧ�����϶���
	public String save() throws Exception{
		
		Teacher s = new Teacher();
		s.setSid(request.getParameter("sid"));
		s.setSname(request.getParameter("sname"));
		s.setGender(request.getParameter("gender"));
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		s.setBirthday(sdf.parse(request.getParameter("birthday")));
		s.setAddress(request.getParameter("address"));
		TeacherDAO sdao = new TeacherDAOImpl();
		sdao.updateTeacher(s);
		return "save_success";
		
	}
	
}
