/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : db_personmanager

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2019-05-08 22:14:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_cj
-- ----------------------------
DROP TABLE IF EXISTS `tb_cj`;
CREATE TABLE `tb_cj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cj_title` varchar(50) NOT NULL,
  `cj_type` char(1) NOT NULL,
  `cj_content` text NOT NULL,
  `cj_money` varchar(50) DEFAULT NULL,
  `cj_time` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_cj
-- ----------------------------
INSERT INTO `tb_cj` VALUES ('4', '羽毛球单打比赛一等奖', '1', '庞*娅、尹*相\r\n\r\n庞*娅、尹*相\r\n\r\n庞*娅、尹*相\r\n\r\n', '0', '2007-10-10');
INSERT INTO `tb_cj` VALUES ('5', '迟到', '0', '邹*思、王*殊、张*庭、粱*冰', '50', '2007-12-4');

-- ----------------------------
-- Table structure for tb_department
-- ----------------------------
DROP TABLE IF EXISTS `tb_department`;
CREATE TABLE `tb_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dt_name` char(10) DEFAULT NULL,
  `dt_createTime` varchar(20) DEFAULT NULL,
  `dt_bz` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_department
-- ----------------------------
INSERT INTO `tb_department` VALUES ('8', 'Java', '2007-11-21', '负责Java应用程序');
INSERT INTO `tb_department` VALUES ('9', 'Java WEB', '2007-11-21', '负责JSP网页');
INSERT INTO `tb_department` VALUES ('15', '快快快', '2014-11-9', '777');

-- ----------------------------
-- Table structure for tb_employee
-- ----------------------------
DROP TABLE IF EXISTS `tb_employee`;
CREATE TABLE `tb_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `em_serialNumber` varchar(30) NOT NULL,
  `em_name` char(10) NOT NULL,
  `em_sex` char(3) NOT NULL,
  `em_age` int(11) NOT NULL,
  `em_IDCard` varchar(30) NOT NULL,
  `em_born` varchar(50) NOT NULL,
  `em_nation` char(10) NOT NULL,
  `em_marriage` char(10) NOT NULL,
  `em_visage` char(10) DEFAULT NULL,
  `em_ancestralHome` char(30) DEFAULT NULL,
  `em_tel` varchar(50) DEFAULT NULL,
  `em_address` varchar(50) DEFAULT NULL,
  `em_afterSchool` varchar(50) DEFAULT NULL,
  `em_speciality` varchar(50) DEFAULT NULL,
  `em_culture` char(10) DEFAULT NULL,
  `em_startime` char(30) DEFAULT NULL,
  `em_departmentId` int(11) NOT NULL,
  `em_typeWork` char(10) DEFAULT NULL,
  `em_creatime` varchar(50) DEFAULT NULL,
  `em_createName` char(30) DEFAULT NULL,
  `em_bz` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_employee
-- ----------------------------
INSERT INTO `tb_employee` VALUES ('1', '001', '刘*红', '女', '25', '22010198********', '1981-02-22', '汉', '未婚', '无', '吉林省长春市', '131808*****', '长春市和平大街', '长春*工大学', '计算机科学与技术', '研究生', '2005-02-02', '9', '程序员', '2007-11-30', 'tsoft', '该员工工作态度积极，具有很强的团队精神');
INSERT INTO `tb_employee` VALUES ('2', '002', '李*尉', '男', '27', '22010419*******', '1981-02-01', '汉', '未婚', '无', '吉林省长春市', '156875*****', '长春市和平大街', '长春*学', '计算机应用', '本科生', '2005-07-07', '8', '程序员', '2007-11-30', 'tsoft', '该员工技术比较突出');
INSERT INTO `tb_employee` VALUES ('31', '003', '谷歌', '男', '6', '6', '6', '汉', '未婚', '无', '6', '6', '6', '6', '6', '研究生', '6', '8', '程序员', '2014-11-9', 'tsoft', '3');

-- ----------------------------
-- Table structure for tb_invitejob
-- ----------------------------
DROP TABLE IF EXISTS `tb_invitejob`;
CREATE TABLE `tb_invitejob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `born` varchar(50) DEFAULT NULL,
  `job` varchar(50) DEFAULT NULL,
  `specialty` varchar(50) DEFAULT NULL,
  `experience` char(10) DEFAULT NULL,
  `teachSchool` varchar(30) DEFAULT NULL,
  `afterSchool` varchar(50) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `createtime` varchar(50) DEFAULT NULL,
  `content` text,
  `isstock` bit(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_invitejob
-- ----------------------------
INSERT INTO `tb_invitejob` VALUES ('1', '任*飞', '男', '27', '1981-01-01', 'Java程序员', '计算机应用', '无', '本科生', '吉*大学', '131******73', '长春市和平大街', '2007-11-29', '应届毕业生，无工作经验', '\0');
INSERT INTO `tb_invitejob` VALUES ('2', '王*凯', '男', '27', '1981-02-02', 'Java程序员', '计算机科学与技术', '无', '研究生', '吉*大学', '131******73', '长春市和平大街', '2007-11-29', '应届毕业生，无工作经验', '\0');
INSERT INTO `tb_invitejob` VALUES ('4', '发呆', '女', '34', '55', '版本', '谷歌', '无', '研究生', '阶级', '666', '好', '2014-11-8', '应届毕业生，无工作经验', '');
INSERT INTO `tb_invitejob` VALUES ('9', '他', '男', '34', '34234', '3', '224', '无', '研究生', '4', '3', '4', '2014-11-9', '555', '\0');

-- ----------------------------
-- Table structure for tb_manager
-- ----------------------------
DROP TABLE IF EXISTS `tb_manager`;
CREATE TABLE `tb_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `managerLevel` char(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_manager
-- ----------------------------
INSERT INTO `tb_manager` VALUES ('1', 'tsoft', '111', '1');
INSERT INTO `tb_manager` VALUES ('2', 'hehe', '123456', '0');

-- ----------------------------
-- Table structure for tb_pay
-- ----------------------------
DROP TABLE IF EXISTS `tb_pay`;
CREATE TABLE `tb_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_emNumber` varchar(30) NOT NULL,
  `pay_emName` char(10) NOT NULL,
  `pay_month` varchar(50) NOT NULL,
  `pay_baseMoney` int(11) NOT NULL,
  `pay_overtime` int(11) NOT NULL,
  `pay_age` int(11) NOT NULL,
  `pay_check` double NOT NULL,
  `pay_absent` double NOT NULL,
  `pay_safety` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_pay
-- ----------------------------
INSERT INTO `tb_pay` VALUES ('7', '004', '上*凯', '2007-12', '2000', '1', '1', '100', '0', '128');
INSERT INTO `tb_pay` VALUES ('8', '007', '王*毅', '2007-12', '4500', '1', '1', '100', '0', '128');
INSERT INTO `tb_pay` VALUES ('10', '003', '呵呵', '2014-11-9', '1', '1', '1', '100', '1', '128');
INSERT INTO `tb_pay` VALUES ('11', '028', '谷歌', '2014-11-9', '2', '2', '2', '100', '2', '128');
INSERT INTO `tb_pay` VALUES ('12', '003', '谷歌', '2019-5', '300', '10', '10', '100', '0', '128');

-- ----------------------------
-- Table structure for tb_train
-- ----------------------------
DROP TABLE IF EXISTS `tb_train`;
CREATE TABLE `tb_train` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tn_man` char(10) DEFAULT NULL,
  `tn_title` varchar(50) DEFAULT NULL,
  `tn_content` varchar(50) DEFAULT NULL,
  `tn_time` char(30) DEFAULT NULL,
  `tn_address` char(30) DEFAULT NULL,
  `tn_join` varchar(50) DEFAULT NULL,
  `tn_bz` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_train
-- ----------------------------
INSERT INTO `tb_train` VALUES ('1', '总经理', '员工守则', '了解每一条款中的内容', '2007-01-01', '2205室', '全体员工', '这个员工守则是新规定的内容，需要开会向全体员工说明');
